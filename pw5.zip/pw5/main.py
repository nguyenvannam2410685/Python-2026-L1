import curses
import input as inp
import output as out
import persistence

students = []
courses = []


def find_course(cid):
    for c in courses:
        if c.get_id() == cid:
            return c
    return None


def find_student(sid):
    for s in students:
        if s.get_id() == sid:
            return s
    return None


def choose_and_compress(scr):
    """Before closing: select compression method, then compress to students.dat."""
    while True:
        out.print_compress_menu(scr, persistence.METHODS)
        choice = inp.ask(scr, "Method: ")
        if choice in persistence.METHODS:
            break
    # make sure the txt files are up to date
    persistence.save_students(students)
    persistence.save_courses(courses)
    persistence.save_marks(students)
    label, method = persistence.METHODS[choice]
    persistence.compress(method)
    scr.addstr(f"\nSaved to {persistence.DATA_FILE} using {label}.\n")
    out.pause(scr)


def main(scr):
    out.init_colors()

    # Upon starting: if students.dat exists -> decompress and load
    if persistence.load_all(students, courses):
        scr.addstr(f"Loaded {len(students)} student(s), {len(courses)} course(s) "
                   f"from {persistence.DATA_FILE}.\n")
        out.pause(scr)

    while True:
        out.print_menu(scr)
        choice = inp.ask(scr, "Choice: ")
        if choice == "0":
            choose_and_compress(scr)
            break
        elif choice == "1":
            out.title(scr, "INPUT STUDENTS")
            inp.input_students(scr, students)
        elif choice == "2":
            out.title(scr, "INPUT COURSES")
            inp.input_courses(scr, courses)
        elif choice == "3":
            out.title(scr, "INPUT MARKS")
            out.print_courses(scr, courses)
            c = find_course(inp.ask(scr, "\nSelect course ID: "))
            if c is None:
                scr.addstr("Course not found.\n")
            else:
                inp.input_marks(scr, students, c)
        elif choice == "4":
            out.title(scr, "COURSES")
            out.print_courses(scr, courses)
        elif choice == "5":
            out.title(scr, "STUDENTS")
            out.print_students(scr, students)
        elif choice == "6":
            out.title(scr, "SHOW MARKS")
            out.print_courses(scr, courses)
            c = find_course(inp.ask(scr, "\nSelect course ID: "))
            if c is None:
                scr.addstr("Course not found.\n")
            else:
                out.print_marks(scr, students, c)
        elif choice == "7":
            out.title(scr, "STUDENT GPA")
            s = find_student(inp.ask(scr, "Student ID: "))
            if s is None:
                scr.addstr("Student not found.\n")
            else:
                out.print_gpa(scr, s, courses)
        elif choice == "8":
            out.title(scr, "STUDENTS SORTED BY GPA (DESC)")
            students.sort(key=lambda s: s.get_gpa(courses), reverse=True)
            out.print_gpa_ranking(scr, students, courses)
        else:
            continue
        out.pause(scr)


curses.wrapper(main)
