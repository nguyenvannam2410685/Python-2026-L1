"""Save / load data: txt files + compressed students.dat (zipfile)."""
import os
import zipfile
from domains import Student, Course

STUDENTS_FILE = "students.txt"
COURSES_FILE = "courses.txt"
MARKS_FILE = "marks.txt"
DATA_FILE = "students.dat"
SEP = "|"

# choice -> (label, zipfile compression constant)
METHODS = {
    "1": ("Deflate", zipfile.ZIP_DEFLATED),
    "2": ("BZip2", zipfile.ZIP_BZIP2),
    "3": ("LZMA", zipfile.ZIP_LZMA),
    "4": ("None (stored)", zipfile.ZIP_STORED),
}


# ---------- write txt files (called after finishing input) ----------
def save_students(students):
    with open(STUDENTS_FILE, "w", encoding="utf-8") as f:
        for s in students:
            f.write(SEP.join([s.get_id(), s.get_name(), s.get_dob()]) + "\n")


def save_courses(courses):
    with open(COURSES_FILE, "w", encoding="utf-8") as f:
        for c in courses:
            f.write(SEP.join([c.get_id(), c.get_name(), str(c.get_credit())]) + "\n")


def save_marks(students):
    with open(MARKS_FILE, "w", encoding="utf-8") as f:
        for s in students:
            for cid, mark in s.get_marks().items():
                f.write(SEP.join([s.get_id(), cid, str(mark)]) + "\n")


# ---------- compress / decompress ----------
def compress(method):
    """Compress the txt files into students.dat."""
    with zipfile.ZipFile(DATA_FILE, "w", compression=method) as z:
        for name in (STUDENTS_FILE, COURSES_FILE, MARKS_FILE):
            if os.path.exists(name):
                z.write(name)


def load_all(students, courses):
    """If students.dat exists: decompress it and load data into the lists."""
    if not os.path.exists(DATA_FILE):
        return False
    with zipfile.ZipFile(DATA_FILE, "r") as z:
        z.extractall()

    if os.path.exists(STUDENTS_FILE):
        with open(STUDENTS_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if line:
                    sid, name, dob = line.split(SEP)
                    students.append(Student(sid, name, dob))

    if os.path.exists(COURSES_FILE):
        with open(COURSES_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if line:
                    cid, name, credit = line.split(SEP)
                    courses.append(Course(cid, name, int(credit)))

    if os.path.exists(MARKS_FILE):
        by_id = {s.get_id(): s for s in students}
        with open(MARKS_FILE, encoding="utf-8") as f:
            for line in f:
                line = line.rstrip("\n")
                if line:
                    sid, cid, mark = line.split(SEP)
                    if sid in by_id:
                        by_id[sid].set_mark(cid, float(mark))
    return True
